import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Image, Button, TextInput, ScrollView, ImageBackground } from 'react-native';
 
//html
export default function App() {
  // estrutura de regras header
  const [nome, setNome] = useState();
  const [img, setImg]  = useState(require("./imagem/leo.jpg"));
 
  const trocaImagem = (x) => {
    x = x.toLowerCase()
        if (x == "janeiro") {
         setImg( require('./imagem/img01.jpg'))
        }
        else if (x == "fevereiro") {
          setImg( require('./imagem/img02.jpg'))
        }
        else if (x == "marco") {
          setImg( require('./imagem/img03.jpg'))
        }
        else if (x == "abril") {
          setImg( require('./imagem/img04.webp'))
        }
        else if (x == "maio") {
          setImg( require('./imagem/img05.jpg'))
        }
        else if (x == "junho") {
          setImg( require('./imagem/img06.webp'))
        }
        else if (x == "julho") {
          setImg( require('./imagem/img07.jpg'))
        }
        else if (x == "agosto") {
          setImg( require('./imagem/img08.jpg'))
        }
        else if (x == "setembro") {
          setImg( require('./imagem/img09.jpg'))
        }
        else if (x == "outubro") {
          setImg( require('./imagem/img10.webp'))
        }
        else if (x == "novembro") {
          setImg( require('./imagem/img11.jpg'))
        }
        else if (x == "dezembro") {
          setImg( require('./imagem/img12.webp'))
        }
        else{
          setNome("Não é um mês válido!")
        }
  }
 
 
  // body
  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, width: '100%' }}>
       <ImageBackground
      source={require('./imagem/paisagem.webp')}
      resizeMode="cover"
      
      style={styles.container}>
      <View style={styles.overlay} />
      <View style={styles.content}>
 
        <Text style={{
          fontSize: 20,
          color: 'white',
          fontWeight: 'bold',
          padding: 20
        }}
        >Digite o mês do seu aniversário: </Text>
 
        <TextInput style={{
          border: '1px solid black',
          padding: 3,
          width: '90%',
          margin: 5,
          height: 30,
          backgroundColor: "#fff"
        }}
          onChangeText={(x) => { setNome(x) }}
        />
        <Button
          title='Descubra sua casa!'
          color='blue'
          onPress={() => {trocaImagem(nome) }}
        />
 
        <Text style={{
          fontSize: 20,
          padding: 50,
          color: 'white',
          fontWeight: 'bold'
        }}>Seu mês: {nome} </Text>

        <Text style={{
          fontSize: 20,
          padding: 50,
          color: 'white',
          fontWeight: 'bold'
        }}>Sua casa:  </Text>
        <Image source={img} 
        style={{ width: 600,  resizeMode: 'contain' }}/>
 
        
      </View>
      </ImageBackground>
    </ScrollView>
  );
}
 
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    width: "100%",
    height: "100%"
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.7)', // 50% de opacidade
  },
  content:{
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  }
});
