import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  FlatList,
  Button,
  Image,
  TouchableOpacity,
  ScrollView
} from 'react-native';

function Lista() {
    const imagens = {
        1: require('../imagem/img01.webp'),
        2: require('../imagem/img02.webp'),
        3: require('../imagem/img03.webp'),
        4: require('../imagem/img04.webp'),
        5: require('../imagem/img05.webp'),
        6: require('../imagem/img06.png'),
        };
  const produtos = [
    { id: 1, nome: 'Notebook Acer', fabricante: 'Acer', preco: 4500.0, descricao: 'Notebook da Acer que roda jogos' },
    { id: 2, nome: 'Notebook Asus', fabricante: 'Asus', preco: 3500.0, descricao: 'Notebook da Asus que roda navegadores' },
    { id: 3, nome: 'Notebook Dell Inspiron', fabricante: 'Dell', preco: 7500.0, descricao: 'Notebook da Dell que roda sistemas' },
    { id: 4, nome: 'Samsung Chromebook', fabricante: 'Samsung', preco: 1500.0, descricao: 'Notebook da Samsung que roda tudo' },
    {id: 5, nome: 'Notebook Positivo', fabricante: 'Positivo', preco: 2000.0, descricao: 'Notebook da Positivo que não roda nada'},
    {id: 6, nome: 'Notebook Lenovo', fabricante: 'Lenovo', preco: 2000.0, descricao: 'Notebook da Lenovo que roda novas coisas'},
  ];

  const [modalVisible, setModalVisible] = useState(false);
  const [produtoSelecionado, setProdutoSelecionado] = useState(null);

  const abrirModal = (produto) => {
    setProdutoSelecionado(produto);
    setModalVisible(true);
  };

  return (
    <View style={css.container}>
        <ScrollView contentContainerStyle={css.scrollContent}>
            <View style={css.caixa}>
            <Text style={css.lista}>Loja de Notebooks</Text>

            <FlatList
                data={produtos}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => {
                return (
                    <View style={css.itemLista}>
                    <Text style={{color: 'white'}}>Nome: {item.nome}</Text>
                    <Text style={{color: 'white'}}>Preço: R${item.preco}</Text>
                    <View style={{ width: '30%' }}>
                        <Button title="Descrição" color="black" onPress={() => abrirModal(item)} />
                    </View>
                    </View>
                );
                }}
            />

            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => setModalVisible(false)}
            >
                <View style={css.modalOverlay}>
                <View style={css.modalView}>
                    <Text style={css.title}>Produto Selecionado</Text>
                    {produtoSelecionado && (
                    <>
                        <Text style={{color: 'white'}}>Nome: {produtoSelecionado.nome}</Text>
                        <Text style={{color: 'white'}}>Fabricante: {produtoSelecionado.fabricante}</Text>
                        <Text style={{color: 'white'}}>Preço: R${produtoSelecionado.preco}</Text>
                        <Text style={{color: 'white'}}>Descrição: {produtoSelecionado.descricao}</Text>
                        <Image
                            source={imagens[produtoSelecionado.id]}
                            style={css.image}
                        />
                    </>
                    )}
                    <TouchableOpacity
                    style={css.button}
                    onPress={() => setModalVisible(false)}
                    >
                    <Text style={{color: 'white'}}>Fechar</Text>
                    </TouchableOpacity>
                </View>
                </View>
            </Modal>
            </View>
        </ScrollView>
    </View>
  );
}

export default Lista;

const css = StyleSheet.create({
  caixa: {
    marginTop: 20,
    width: '90%',
    alignSelf: 'center',
  },
  lista: {
    height: 50,
    marginBottom: 10,
    textAlign: 'center',
    textAlignVertical: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white'
  },
  itemLista: {
    backgroundColor: '#3a3a3aff',
    borderWidth: 1,
    borderColor: '#000',
    borderRadius: 10,
    margin: 10,
    padding: 10,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  modalView: {
    backgroundColor: '#3a3a3aff',
    borderRadius: 10,
    padding: 20,
    alignItems: 'center',
    elevation: 5,
    width: '80%',
  },
  title: {
    fontSize: 18,
    marginBottom: 10,
    color: 'white',
  },
  image: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginBottom: 15,
  },
  button: {
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'black',
  },
  container: {
    flex: 1,
    backgroundColor: '#565656',  
     width: '100%',
    padding:10
  },
  scrollView: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingVertical: 20,
  },
});
